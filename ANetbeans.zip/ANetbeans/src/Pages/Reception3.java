package Pages;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.Vector;
import javafx.scene.control.DatePicker;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Reception3 extends JFrame {
    JFrame frame;
    JPanel panel_heading, panel_booking, panel1_data, panel1_button, panel1_search, panel1_bookingT, panel_checkIn;
    JLabel logo, lbl_title, lbl_registrationID, lbl_roomClass, lbl_roomNo, lbl_checkIn, lbl_checkOut
            , lbl_roomType, lbl_status;
    JTextField txt_registrationID, txt_checkIn, txt_checkOut, txt_searchField;
    JButton btn_save , btn_edit, btn_remove, btn_clear,  btn_search, btn_refresh;
    ImageIcon img;
    JComboBox cmb_roomClass, cmb_roomNo, cmb_roomType, cmb_status;
    DatePicker date;
    JTable table1;
    DefaultTableModel tableModel;
    JScrollPane scrollPane, Sc1_table;
    JPanel panel_checkInD, panel_checkOutD;
    //objects of check in tab
    JPanel panel2_checkInT, panel2_search;
    JScrollPane Sc2_table;
    //objects of check Out tab
    JPanel panel3_checkOutT, panel3_search;
    JScrollPane Sc3_table_checkOut;
    //objects of billing tab
    JPanel panel_billing, panel4_billingT, panel4_data ;
    JScrollPane Sc4_table_billing;
    JLabel lbl_bookingID,lbl_tender, lbl_returned, lbl_gap, lbl_total;
    JTextField txt_bookingID, txt_tender, txt_returned, txt_total;
    JButton btn_add, btn_print, btn4_search;
//customer details
    JPanel panel_customerDetails, panel5_data, panel5_customerT, panel5_button;
    JScrollPane Sc5_table;
    JPanel panel5_customerData;
    JLabel lbl_regID, lbl_name,lbl_address,lbl_email,lbl_password, lbl_phone, lbl_creditCard, lbl_age;
    JTextField txt_regID, txt_name, txt_address, txt_email, txt_password, txt_phone, txt_creditCard, txt_age;
    
    public Reception3() {
        frame = new JFrame();
        frame.setTitle("Luton Hotel - Reception");
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setBackground(Color.ORANGE); 

        //Fonts to select
        Font fTitle=new Font("Segoe UI Black", Font.TRUETYPE_FONT,70);
        Font font1 =new Font("Courier", Font.PLAIN,20);
        Font font2 =new Font("Courier", Font.PLAIN,25);

        panel_heading = new JPanel();
        lbl_title = new JLabel("Luton hotel");
        lbl_title.setFont(fTitle);
        panel_heading.setBounds(0, 0, 1920, 110);
        img = new ImageIcon("src\\Image\\Hlogo.jpg");
        logo = new JLabel(img);
        logo.setPreferredSize(new Dimension(100,100));
        panel_heading.add(logo);
        panel_heading.add(lbl_title);
        
        panel1_data = new JPanel();
        //panel_data.setLayout(null);
        //Registration ID details
        lbl_registrationID = new JLabel("Registration ID : ");
        lbl_registrationID.setFont(font1);
        lbl_registrationID.setBounds(40, 150, 400, 800);
        txt_registrationID = new JTextField(20);
        txt_registrationID.setFont(font1);
        //Room Type 
        /*lbl_roomClass = new JLabel("Room Type");        
        lbl_roomClass.setFont(font1);
        Vector roomClass = new Vector();
        roomClass.add("Basic");
        roomClass.add("Standard");
        roomClass.add("Deluxe");
        cmb_roomClass = new JComboBox(roomClass);
        cmb_roomClass.setFont(font1);*/
        
        lbl_roomNo = new JLabel("Room Number :");        
        lbl_roomNo.setFont(font1);
        Vector roomNo = new Vector();
        roomNo.add("100");
        roomNo.add("101");
        roomNo.add("102");
        roomNo.add("103");
        roomNo.add("104");
        roomNo.add("105");
        roomNo.add("106");
        roomNo.add("107");
        roomNo.add("108");
        roomNo.add("109");
        roomNo.add("110");
        roomNo.add("111");
        cmb_roomNo = new JComboBox(roomNo);
        cmb_roomNo.setFont(font1);
        
//Room Type
        lbl_roomType = new JLabel("Room Type :"); lbl_roomType.setFont(font1);
        Vector roomType = new Vector();
        roomType.add("Single");
        roomType.add("Twin");
        roomType.add("Double");
        cmb_roomType = new JComboBox(roomType); cmb_roomType.setFont(font1);
        
        lbl_status = new JLabel("Status :"); lbl_status.setFont(font1);
        Vector status = new Vector();
        status.add("Booked");
        status.add("Active");
        status.add("Cancelled");
        status.add("Completed");
        cmb_status = new JComboBox(status); cmb_status.setFont(font1);
//check in date
        lbl_checkIn = new JLabel("Check In Date :");
        lbl_checkIn.setFont(font1);
        txt_checkIn = new JTextField("DD-MM-YYYY");
        txt_checkIn.setFont(font1);
        lbl_checkOut = new JLabel("Check out Date :");
        lbl_checkOut.setFont(font1);
        txt_checkOut = new JTextField("DD-MM-YYYY");
        txt_checkOut.setFont(font1);
        
        /*date = new DatePicker();
        UtilDateModel model = new UtilDateModel();
        JDatePanelImpl datePanel = new JDatePanelImpl(model);
        JDatePickerImpl datePicker = new JDatePickerImpl(datePanel);
        */
        
        
        
        panel1_data.setLayout(new GridLayout(6,2,-60,20));
        panel1_data.add(lbl_registrationID);
        panel1_data.add(txt_registrationID);
        //panel1_data.add(lbl_roomClass);
        //panel1_data.add(cmb_roomClass);
        panel1_data.add(lbl_roomNo);
        panel1_data.add(cmb_roomNo);
        panel1_data.add(lbl_roomType);
        panel1_data.add(cmb_roomType);
        panel1_data.add(lbl_status);
        panel1_data.add(cmb_status);
        panel1_data.add(lbl_checkIn);
        panel1_data.add(txt_checkIn);
        panel1_data.add(lbl_checkOut);
        panel1_data.add(txt_checkOut);
        panel1_data.setBackground(Color.getHSBColor(100, 5, 80));
        panel1_data.setBounds(30,130, 450,450);
        
        
        
        

        
        
        panel1_button = new JPanel();
        btn_save = new JButton("Save");btn_save.setFont(font1);
        btn_edit = new JButton("Edit");btn_edit.setFont(font1);
        btn_remove = new JButton("Remove");btn_remove.setFont(font1);
        btn_clear = new JButton("Clear");btn_clear.setFont(font1);

        panel1_button.setLayout(new GridLayout(1,4,7,0));
        panel1_button.add(btn_save);
        panel1_button.add(btn_edit);
        panel1_button.add(btn_remove);
        panel1_button.add(btn_clear);
        panel1_button.setBounds(15, 640, 500, 60);
        panel1_button.setBackground(Color.getHSBColor(100, 5, 80));
        
        panel1_search = new JPanel();
        txt_searchField = new JTextField(20);txt_searchField.setFont(font1);
        btn_refresh = new JButton("Refresh");btn_refresh.setFont(font2);
        btn_search = new JButton("Search");btn_search.setFont(font2);
        panel1_search.add(txt_searchField);
        panel1_search.add(btn_search);
        panel1_search.add(btn_refresh);
        panel1_search.setBounds(1000, 30, 600, 50);
        
        
        panel1_bookingT = new JPanel();
        DefaultTableModel table_bookingT = new DefaultTableModel();
        JTable table = new JTable(table_bookingT);
        table_bookingT.addColumn("Reg ID");
        table_bookingT.addColumn("Name");
        table_bookingT.addColumn("Check In");
        table_bookingT.addColumn("Check Out");
        table_bookingT.addColumn("Room No");
        table_bookingT.addColumn("Room Type");
        table_bookingT.addColumn("Status");
        table_bookingT.insertRow(0, new Object[] { "HTML5" });
        table_bookingT.insertRow(0, new Object[] { "JavaScript" });
        table_bookingT.insertRow(0, new Object[] { "jQuery" });
        table_bookingT.insertRow(0, new Object[] { "1","Sudip","05-02-2021","06-03-2021", "100", "Single", "Booked"});
        table_bookingT.insertRow(table_bookingT.getRowCount(), new Object[] { "ExpressJS" });
        Sc1_table =  new JScrollPane(table);
        Sc1_table.setPreferredSize(new Dimension(1290,658));
        panel1_bookingT.add(Sc1_table);
        panel1_bookingT.setBounds(540, 100, 1300, 670);
        panel1_bookingT.setBackground(Color.black);
        
        panel_booking = new JPanel();
        panel_booking.setLayout(null);
        panel_booking.add(panel1_data);
        panel_booking.add(panel1_bookingT);
        panel_booking.add(panel1_button);
        panel_booking.add(panel1_search);
        panel_booking.setBounds(30,140,1860,880); 
        panel_booking.setBackground(Color.getHSBColor(100, 5, 80));
        
        panel_checkInD  = new JPanel();
        
        
        panel2_checkInT = new JPanel();
        DefaultTableModel tableModel_checkIn = new DefaultTableModel();
        JTable table_checkIn = new JTable(tableModel_checkIn);
        tableModel_checkIn.addColumn("Reg ID");
        tableModel_checkIn.addColumn("Name");
        tableModel_checkIn.addColumn("Check In");
        tableModel_checkIn.addColumn("Check Out");
        tableModel_checkIn.addColumn("Room No");
        tableModel_checkIn.addColumn("Room Type");
        tableModel_checkIn.addColumn("Status");
        tableModel_checkIn.insertRow(0, new Object[] { "HTML5" });
        tableModel_checkIn.insertRow(0, new Object[] { "JavaScript" });
        tableModel_checkIn.insertRow(0, new Object[] { "jQuery" });
        tableModel_checkIn.insertRow(0, new Object[] { "1","Sudip","05-02-2021","06-03-2021", "100", "Single", "Booked"});
        tableModel_checkIn.insertRow(tableModel_checkIn.getRowCount(), new Object[] { "ExpressJS" });
        Sc2_table =  new JScrollPane(table_checkIn);
        Sc2_table.setPreferredSize(new Dimension(1290,658));
        panel2_checkInT.add(Sc2_table);
        panel2_checkInT.setBackground(Color.black);
        panel2_checkInT.setBounds(540, 100, 1300, 670);
        
        //Search panel in check in tab and it share txt_searchField from other tabs
        panel2_search = new JPanel();
        txt_searchField = new JTextField(20);txt_searchField.setFont(font1);
        btn_refresh = new JButton("Refresh");btn_refresh.setFont(font2);
        btn_search = new JButton("Search");btn_search.setFont(font2);
        panel2_search.add(txt_searchField);
        panel2_search.add(btn_search);
        panel2_search.add(btn_refresh);
        panel2_search.setBounds(1000, 30, 600, 50);
        
        
        
        panel_checkInD.setLayout(null);
        panel_checkInD.add(panel2_checkInT);
        panel_checkInD.add(panel2_search);
        panel_checkInD.setBounds(30,140,1860,880);
        panel_checkInD.setBackground(Color.getHSBColor(100, 5, 80));
        
//check out panel
        panel_checkOutD = new JPanel();
        panel3_checkOutT = new JPanel();
        DefaultTableModel tableModel_checkOut = new DefaultTableModel();
        JTable table_checkOut = new JTable(tableModel_checkOut);
        tableModel_checkOut.addColumn("Reg ID");
        tableModel_checkOut.addColumn("Name");
        tableModel_checkOut.addColumn("Check In");
        tableModel_checkOut.addColumn("Check Out");
        tableModel_checkOut.addColumn("Room No");
        tableModel_checkOut.addColumn("Room Type");
        tableModel_checkOut.addColumn("Status");
        tableModel_checkOut.insertRow(0, new Object[] { "HTML5" });
        tableModel_checkOut.insertRow(0, new Object[] { "JavaScript" });
        tableModel_checkOut.insertRow(0, new Object[] { "jQuery" });
        tableModel_checkIn.insertRow(0, new Object[] { "1","Sudip","05-02-2021","06-03-2021", "100", "Single", "Booked"});
        tableModel_checkIn.insertRow(tableModel_checkIn.getRowCount(), new Object[] { "ExpressJS" });
        Sc3_table_checkOut =  new JScrollPane(table_checkOut);
        Sc3_table_checkOut.setPreferredSize(new Dimension(1290,658));
        panel3_checkOutT.add(Sc3_table_checkOut);
        panel3_checkOutT.setBackground(Color.black);
        panel3_checkOutT.setBounds(540, 100, 1300, 670);
        
        panel3_search = new JPanel();
        txt_searchField = new JTextField(20);txt_searchField.setFont(font1);
        btn_refresh = new JButton("Refresh");btn_refresh.setFont(font2);
        btn_search = new JButton("Search");btn_search.setFont(font2);
        panel3_search.add(txt_searchField);
        panel3_search.add(btn_search);
        panel3_search.add(btn_refresh);
        panel3_search.setBounds(1000, 30, 600, 50);
        
        
        panel_checkOutD.setLayout(null);
        panel_checkOutD.add(panel3_checkOutT);
        panel_checkOutD.add(panel3_search); //shared search panel from above
        panel_checkOutD.setBounds(30,140,1860,880);
        panel_checkOutD.setBackground(Color.getHSBColor(100, 5, 80));
        
        panel4_billingT = new JPanel();
        DefaultTableModel tableModel_billing = new DefaultTableModel();
        JTable table_billing = new JTable(tableModel_billing);
        tableModel_billing.addColumn("Reg ID");
        tableModel_billing.addColumn("Booking ID");
        tableModel_billing.addColumn("Name");
        tableModel_billing.addColumn("Check In");
        tableModel_billing.addColumn("Check Out");
        tableModel_billing.addColumn("Room No");
        tableModel_billing.addColumn("Room Charge");
        tableModel_billing.addColumn("Status");
        tableModel_billing.insertRow(0, new Object[] { "HTML5" });
        tableModel_billing.insertRow(0, new Object[] { "JavaScript" });
        tableModel_billing.insertRow(0, new Object[] { "jQuery" });
        tableModel_checkIn.insertRow(0, new Object[] { "1","Sudip","05-02-2021","06-03-2021", "100", "Single", "Booked"});
        tableModel_checkIn.insertRow(tableModel_checkIn.getRowCount(), new Object[] { "ExpressJS" });
        Sc4_table_billing =  new JScrollPane(table_billing);
        Sc4_table_billing.setPreferredSize(new Dimension(1290,658));
        panel4_billingT.add(Sc4_table_billing);
        panel4_billingT.setBackground(Color.black);
        panel4_billingT.setBounds(540, 50, 1300, 620);
        
//billing data or input part
        panel4_data = new JPanel();
        panel4_data.setLayout(new GridLayout(5,2,-100,50));
        lbl_bookingID = new JLabel("Booking ID :"); lbl_bookingID.setFont(font1);
        txt_bookingID = new JTextField(); txt_bookingID.setFont(font1);
        lbl_tender = new JLabel("Tender :"); lbl_tender.setFont(font1);
        txt_tender = new JTextField(); txt_tender.setFont(font1);
        lbl_returned = new JLabel("Returned :");lbl_returned.setFont(font1);
        txt_returned = new JTextField(); txt_returned.setFont(font1);
        lbl_total = new JLabel("Total :");lbl_total.setFont(font1);
        txt_total = new JTextField(); txt_total.setFont(font1);
        lbl_gap = new JLabel(); lbl_gap.setFont(font1);
        btn_add = new JButton("ADD"); btn_add.setFont(font1);
        panel4_data.add(lbl_bookingID);
        panel4_data.add(txt_bookingID);
        panel4_data.add(lbl_tender);
        panel4_data.add(txt_tender);
        panel4_data.add(lbl_returned);
        panel4_data.add(txt_returned);
        panel4_data.add(lbl_total);
        panel4_data.add(txt_total);
        panel4_data.add(lbl_gap);
        panel4_data.add(btn_add);
        panel4_data.setBackground(Color.getHSBColor(100, 5, 80));
        panel4_data.setBounds(30,130, 350,450);
        
        btn_print = new JButton("Print"); btn_print.setFont(font2);
        btn_print.setBounds(1700, 725, 100, 50);
        btn4_search = new JButton("Search"); btn4_search.setFont(font2);
        btn4_search.setBounds(390, 130 , 130, 50);
        
        panel_billing = new JPanel();
        panel_billing.setLayout(null);
        panel_billing.setBackground(Color.getHSBColor(100, 5, 80));
        panel_billing.add(panel4_billingT);
        panel_billing.add(panel4_data);
        panel_billing.add(btn_print);
        panel_billing.add(btn4_search);        
        
//customers details form
        panel5_customerT = new JPanel();     
        DefaultTableModel table_customerT= new DefaultTableModel();
        JTable customerDetails = new JTable(table_customerT);
        table_customerT.addColumn("Reg ID");
        table_customerT.addColumn("Name");
        table_customerT.addColumn("Address");
        table_customerT.addColumn("Email");
        table_customerT.addColumn("Password");
        table_customerT.addColumn("Phone");
        table_customerT.addColumn("Credit Card");
        table_customerT.addColumn("Age");
        table_customerT.insertRow(0, new Object[] { "HTML5" });
        table_customerT.insertRow(0, new Object[] { "JavaScript" });
        table_customerT.insertRow(0, new Object[] { "jQuery" });
        table_customerT.insertRow(0, new Object[] { "1","Sudip","Chitwan","happysudip450@gamil.com", "something", "9866115102", "6547893216545", "18-29"});
        table_customerT.insertRow(table_customerT.getRowCount(), new Object[] { "ExpressJS" });
        Sc5_table =  new JScrollPane(customerDetails);
        Sc5_table.setPreferredSize(new Dimension(1290,658));
        panel5_customerT.add(Sc5_table);
        panel5_customerT.setBackground(Color.black);
        panel5_customerT.setBounds(540, 100, 1300, 670);
        
        
        
        panel5_customerData = new JPanel();
        panel5_customerData.setLayout(new GridLayout(8,2,-60,20));
        lbl_regID = new JLabel("Registration ID : "); lbl_regID.setFont(font1);
        lbl_name = new JLabel("Name : "); lbl_name.setFont(font1);
        lbl_address = new JLabel("Address : "); lbl_address.setFont(font1);
        lbl_email = new JLabel("Email : "); lbl_email.setFont(font1);
        lbl_password = new JLabel("Password : "); lbl_password.setFont(font1);
        lbl_phone = new JLabel("Phone : "); lbl_phone.setFont(font1);
        lbl_creditCard = new JLabel("Credit Card : "); lbl_creditCard.setFont(font1);
        lbl_age = new JLabel("Age : "); lbl_age.setFont(font1);
        txt_regID = new JTextField(); txt_regID.setFont(font1);
        txt_name = new JTextField(); txt_name.setFont(font1);
        txt_address = new JTextField(); txt_address.setFont(font1);
        txt_email = new JTextField(); txt_email.setFont(font1);
        txt_password = new JTextField(); txt_password.setFont(font1);
        txt_phone = new JTextField(); txt_phone.setFont(font1);
        txt_creditCard = new JTextField();txt_creditCard.setFont(font1);
        txt_age = new JTextField(); txt_age.setFont(font1);
        panel5_customerData.add(lbl_regID);
        panel5_customerData.add(txt_regID);
        panel5_customerData.add(lbl_name);
        panel5_customerData.add(txt_name);
        panel5_customerData.add(lbl_address);
        panel5_customerData.add(txt_address);
        panel5_customerData.add(lbl_email);
        panel5_customerData.add(txt_email);
        panel5_customerData.add(lbl_password);
        panel5_customerData.add(txt_password);
        panel5_customerData.add(lbl_phone);
        panel5_customerData.add(txt_phone);
        panel5_customerData.add(lbl_creditCard);
        panel5_customerData.add(txt_creditCard);
        panel5_customerData.add(lbl_age);
        panel5_customerData.add(txt_age);
        panel5_customerData.setBounds(30,130, 450,450);
        panel5_customerData.setBackground(Color.getHSBColor(100, 5, 80));
        
        JButton btn5_update, btn5_delete, btn5_save;
        panel5_button = new JPanel();
        panel5_button.setLayout(new GridLayout(1,3,15,0));
        btn5_save = new JButton("Save"); btn5_save.setFont(font1);
        btn5_update = new JButton("Update"); btn5_update.setFont(font1);
        btn5_delete = new JButton("Delete"); btn5_delete.setFont(font1);
        
        panel5_button.setBackground(Color.getHSBColor(100, 5, 80));
        panel5_button.setBounds(30, 600, 450, 50);
        panel5_button.add(btn5_save);
        panel5_button.add(btn5_update);
        panel5_button.add(btn5_delete);
        
        panel_customerDetails = new JPanel();
        panel_customerDetails.setLayout(null);
        panel_customerDetails.setBackground(Color.getHSBColor(100, 5, 80));
        panel_customerDetails.add(panel5_customerData);
        panel_customerDetails.add(panel5_customerT);
        panel_customerDetails.add(panel5_button);
        
        JTabbedPane tab = new JTabbedPane();
        tab.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
        tab.addTab("Make a Booking ", panel_booking);
        tab.addTab("Check-In Details ", panel_checkInD);
        tab.addTab("Check-Out Details ", panel_checkOutD);
        tab.addTab(" Billing ", panel_billing);
        tab.addTab(" Customer Details ", panel_customerDetails);
        tab.setBounds(30,140,1860,880);
        tab.setFont( new Font( "Dialog", Font.BOLD|Font.ITALIC, 24 ) );
        
        frame.setLayout(null);
        frame.add(panel_heading);
        frame.add(tab);
        frame.setVisible(true);
    }
    public static void main(String args[])	{
            Reception3 tdemo=new Reception3();

    }
}
