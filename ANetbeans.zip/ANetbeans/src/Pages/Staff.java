/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pages;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Staff {

    JFrame frame;
    JPanel panel_head, panel1_customerT, panel_customer, panel_search;
    ImageIcon img;
    JLabel logo, lbl_title;
    JTextField txt_search;
    JButton btn_search;
    JScrollPane Sc1_service , Sc2_customer;
//for extra services panel
    JPanel panel_service, panel1_data, panel_serviceT;
    JLabel lbl_bookingID ,lbl_service, lbl_serviceCharge, lbl_gap;
    JTextField txt_bookingID ,txt_service, txt_serviceCharge;
    JButton btn_add;
    
    public Staff() {
        frame = new JFrame("Staff");
        frame.setSize(new Dimension(250, 250));
        frame.setResizable(false);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBackground(Color.getHSBColor(100, 5, 80));
        //Fonts to select
        Font fTitle = new Font("Segoe UI Black", Font.TRUETYPE_FONT, 70);
        Font font1 = new Font("Courier", Font.PLAIN, 20);
        Font font2 = new Font("Courier", Font.PLAIN, 25);
        
        //header part
        panel_head = new JPanel();
        img = new ImageIcon("src\\Image\\Hlogo.jpg");
        logo = new JLabel(img);
        logo.setPreferredSize(new Dimension(100, 100));
        panel_head.add(logo);
        lbl_title = new JLabel("Luton Hotel");
        lbl_title.setFont(fTitle);
        panel_head.add(lbl_title);
        //panel_head.setBackground(Color.LIGHT_GRAY);
        panel_head.setBounds(0, 0, 1920, 110);

//customer information table
        panel_customer = new JPanel();
        panel1_customerT = new JPanel();     
        DefaultTableModel table_customerT= new DefaultTableModel();
        JTable customerDetails = new JTable(table_customerT);
        table_customerT.addColumn("Reg ID");
        table_customerT.addColumn("Booking ID");
        table_customerT.addColumn("Name");
        table_customerT.addColumn("Address");
        table_customerT.addColumn("Email");
        table_customerT.addColumn("Password");
        table_customerT.addColumn("Phone");
        table_customerT.addColumn("Credit Card");
        table_customerT.addColumn("Age");
        table_customerT.insertRow(0, new Object[] { "HTML5" });
        table_customerT.insertRow(0, new Object[] { "JavaScript" });
        table_customerT.insertRow(0, new Object[] { "jQuery" });
        table_customerT.insertRow(0, new Object[] { "1","Sudip","Chitwan","happysudip450@gamil.com", "something", "9866115102", "6547893216545", "18-29"});
        table_customerT.insertRow(table_customerT.getRowCount(), new Object[] { "ExpressJS" });
        Sc2_customer =  new JScrollPane(customerDetails);
        Sc2_customer.setPreferredSize(new Dimension(1290,670));
        panel1_customerT.add(Sc2_customer);
        panel1_customerT.setBackground(Color.black);
        panel1_customerT.setBounds(540, 100, 1300, 670);
        
        panel_search = new JPanel();
        txt_search = new JTextField(20); txt_search.setFont(font1);
        btn_search = new JButton("Search"); btn_search.setFont(font1);
        panel_search.add(txt_search);
        panel_search.add(btn_search);
        panel_search.setBounds(1000, 30, 500, 50);
        
//adding all panel of customer details into a single panel
        panel_customer.setLayout(null);
        panel_customer.add(panel1_customerT);
        panel_customer.add(panel_search);
        panel_customer.setBackground(Color.getHSBColor(100, 5, 80));
        
//form to add extra service charge into customer account
        panel1_data = new JPanel();
        panel1_data.setLayout(new GridLayout(4,2,-40,50));
        lbl_bookingID = new JLabel("Booking ID : "); lbl_bookingID.setFont(font1);
        txt_bookingID = new JTextField(); txt_bookingID.setFont(font1);
        lbl_service = new JLabel(" Service : "); lbl_service.setFont(font1);
        txt_service = new JTextField(); txt_service.setFont(font1);
        lbl_serviceCharge = new JLabel("Service Charge : "); lbl_serviceCharge.setFont(font1);
        txt_serviceCharge = new JTextField(); txt_serviceCharge.setFont(font1);
        lbl_gap = new JLabel();
        btn_add = new JButton("ADD"); btn_add.setFont(font2);
        panel1_data.add(lbl_bookingID);
        panel1_data.add(txt_bookingID);
        panel1_data.add(lbl_service);
        panel1_data.add(txt_service);
        panel1_data.add(lbl_serviceCharge);
        panel1_data.add(txt_serviceCharge);
        panel1_data.add(lbl_gap);
        panel1_data.add(btn_add);
        panel1_data.setBounds(30,130, 450,300);
        panel1_data.setBackground(Color.getHSBColor(100, 5, 80));
        
//service charge table
        panel_serviceT = new JPanel();
        DefaultTableModel table_bookingT = new DefaultTableModel();
        JTable table = new JTable(table_bookingT);
        table_bookingT.addColumn("Booking ID");
        table_bookingT.addColumn("Name");
        table_bookingT.addColumn("Phone");
        table_bookingT.addColumn("Service Used");
        table_bookingT.addColumn("Service Charge");
        table_bookingT.insertRow(0, new Object[] { "HTML5" });
        table_bookingT.insertRow(0, new Object[] { "JavaScript" });
        table_bookingT.insertRow(0, new Object[] { "jQuery" });
        table_bookingT.insertRow(0, new Object[] { "1","Sudip","9866115102","Swimming", "500"});
        table_bookingT.insertRow(table_bookingT.getRowCount(), new Object[] { "ExpressJS" });
        Sc1_service =  new JScrollPane(table);
        Sc1_service.setPreferredSize(new Dimension(1290,670));
        panel_serviceT.add(Sc1_service);
        panel_serviceT.setBounds(540, 100, 1300, 670);
        panel_serviceT.setBackground(Color.black);




        panel_service = new JPanel();
        panel_service.add(panel1_data);
        panel_service.add(panel_serviceT);
        panel_service.setLayout(null);
        
        panel_service.setBackground(Color.getHSBColor(100, 5, 80));
        
        
        
        JTabbedPane tab = new JTabbedPane();
        tab.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
        tab.addTab(" Service ", panel_service);
        tab.addTab(" Customer Details", panel_customer);
        tab.setBounds(30,140,1860,880);
        tab.setFont( new Font( "Dialog", Font.BOLD|Font.ITALIC, 24 ) );
        
        
        frame.setLayout(null);
        frame.add(panel_head);
        frame.add(tab);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new Staff();
    }
}
