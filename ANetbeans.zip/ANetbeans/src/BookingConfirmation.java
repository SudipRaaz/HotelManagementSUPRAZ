/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author raaz4
 */
public class BookingConfirmation {
    JFrame frame;
    JPanel panel_c, panel_data;
    public void Booking(){
        frame=new JFrame();
        frame.setTitle("JInternal Frame Test");
        frame.setSize(1500, 8000);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //panel content
        panel_data = new JPanel();
        lbl_check
        
        
        
        
        
        //container of all panels 
        panel_c = new JPanel();
        panel_c.setLayout(null);
        panel_c.setBackground(Color.black);
        
        
        
        frame.add(panel_c);
        frame.setVisible(true);
    }
    public static void main(String [] args){
        BookingConfirmation bk = new BookingConfirmation();
        bk.Booking();
    }
}
