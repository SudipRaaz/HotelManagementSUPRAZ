/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.util.Vector;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;

/**
 *
 * @author raaz4
 */
public class Reception {
    JFrame frame;
    JLabel lbl_title, title, logo;
    JPanel panel, panel1,panel_table;
    ImageIcon img;
    JLabel lbl_registrationID, lbl_room, lbl_checkIn, lbl_checkOut, lbl_roomType, lbl_roomNo;
    JTextField txt_registrationID;
    JComboBox cmb_roomInfo, cmb_roomType, cmb_roomNo; 
    public Reception(){
        frame = new JFrame();
        frame.setTitle("Luton Hotel - Reception");
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setBackground(Color.ORANGE); 
        
        //Fonts to select
        Font fTitle=new Font("Segoe UI Black", Font.TRUETYPE_FONT,70);
        Font font1 =new Font("Courier", Font.PLAIN,20);
        Font font2 =new Font("Courier", Font.PLAIN,25);
        
        
        panel = new JPanel();
        lbl_title = new JLabel("Luton hotel");
        lbl_title.setFont(fTitle);
        panel.setBounds(0, 0, 1920, 110);
        img = new ImageIcon("src\\Image\\Hlogo.jpg");
        logo = new JLabel(img);
        logo.setPreferredSize(new Dimension(100,100));
        panel.add(logo);
        panel.add(lbl_title);
        
        panel1 = new JPanel();
        lbl_registrationID = new JLabel("Registration ID : ");
        lbl_registrationID.setFont(font1);
        txt_registrationID = new JTextField(20);
        txt_registrationID.setFont(font1);
        lbl_roomType = new JLabel("Room Type");        
        lbl_roomType.setFont(font1);      
        
        Vector roomType = new Vector();
        roomType.add("Basic");
        roomType.add("Standard");
        roomType.add("Deluxe");
        cmb_roomType = new JComboBox(roomType);
        cmb_roomType.setFont(font1);
        
        panel1.add(lbl_registrationID);
        panel1.add(txt_registrationID);
        panel1.add(lbl_roomType);
        panel1.add(cmb_roomType);
        panel1.setBounds(20, 135, 500, 900);
        
        panel_table = new JPanel();
        String []columns = {"Reg ID","F.NAME","L.NAME","CHECK IN","CHECK OUT","ROOM NO","TYPE","STATUS"};
	Object [][] data = {
            {"1","sudip","adhikari","03/04","03/07","102","deluxe","pending","pending"}
		};
		
        JTable tbl1 = new JTable(data, columns);
        panel_table.add(tbl1);
        panel_table.setBounds(540, 135, 1300, 900);
        
        
        frame.setLayout(null);
        frame.add(panel);
        frame.add(panel1);
        frame.add(panel_table);
        frame.setVisible(true);
    }
    public static void main(String[] args){
        Reception reception = new Reception();
        
    }
}
