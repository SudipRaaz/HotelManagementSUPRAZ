/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import java.util.Vector;
import java.awt.Checkbox;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
/**
 *
 * @author raaz4
 */
public class Registration {
   
        JFrame frame;
        JLabel title,lbl_name,lbl_address,lbl_email,lbl_phone, lbl_gender,
                lbl_male,lbl_female,lbl_ageGroup,lbl_hobbies;
        JTextField txt_id,txt_name,txt_address,txt_email,txt_phone;
        JRadioButton rd_genderFemale,rd_genderMale,rd_others;
        JComboBox ageGroup;
        Checkbox hobbie1,hobbie2,hobbie3;
        JButton submit, cancel;
        JPasswordField txt_pass;
        JTextArea txt_comment;
        JPanel panel1,panel2,panel3,panel4,panel5;
        public void RegistrationForm(){
            frame = new JFrame();
            frame.setTitle("basic controls");
            frame.setSize(400,300);
            frame.setLocationRelativeTo(null);
            frame.setLayout(new FlowLayout());
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
            Font fTitle=new Font("Courier", Font.TRUETYPE_FONT,22);
            Font fEmail =new Font("Courier", Font.PLAIN,17);
            Font login =new Font("Courier", Font.PLAIN,17);

            title = new JLabel();
            title.setText("                                      Registration Form                                   ");
            //panel1.add(title);
            
            
            lbl_name = new JLabel();
            lbl_name.setText("Enter Name :      ");
            txt_name = new JTextField();
            txt_name.setColumns(20);
            
            lbl_address = new JLabel();
            lbl_address.setText("Enter address : ");
            txt_address = new JTextField();
            txt_address.setColumns(20);
            
            lbl_email = new JLabel();
            lbl_email.setText("Enter email :       ");
            txt_email = new JTextField();
            txt_email.setColumns(20);
            
            lbl_phone = new JLabel();
            lbl_phone.setText("Enter phone :     ");
            txt_phone = new JTextField();
            txt_phone.setColumns(20);
            
            lbl_gender = new JLabel();
            lbl_gender.setText("Gender :         ");
            rd_genderMale = new JRadioButton();
            rd_genderMale.setText("Male");
            rd_genderFemale = new JRadioButton();
            rd_genderFemale.setText("Female");
            rd_others = new JRadioButton();
            rd_others.setText(" Others ");
            ButtonGroup bg = new ButtonGroup();
            bg.add(rd_genderMale);
            bg.add(rd_genderFemale);
            bg.add(rd_others);
            
            
            Vector ageRange = new Vector();//also array can be used instead of vector
            ageRange.add(" Under 18");
            ageRange.add("    15-29");
            ageRange.add("    30-45");
            ageRange.add("    45 plus");
            ageGroup = new JComboBox(ageRange);
            lbl_ageGroup = new JLabel();
            lbl_ageGroup.setText("         Select Age Group                          :          ");
            
            /*lbl_hobbies = new JLabel("Hobbies : ");
            hobbie1 = new Checkbox(" Reading ");
            hobbie2 = new Checkbox(" Playing ");
            hobbie3 = new Checkbox(" Others                  ");
            
            
            
            txt_pass = new JPasswordField();
            txt_pass.setEchoChar('*');
            txt_pass.setColumns(10);
            
            txt_comment = new JTextArea(5,20);
            */
            submit = new JButton("Register");
            cancel = new JButton("Cancel");
            
            //submit.addActionListeners();
            
            
            frame.add(title);
            //frame.add(txt_id);
            frame.add(lbl_name);
            frame.add(txt_name);
            frame.add(lbl_address);
            frame.add(txt_address);
            frame.add(lbl_email);
            frame.add(txt_email);
            frame.add(lbl_phone);
            frame.add(txt_phone);
            
            frame.add(lbl_gender);
            frame.add(rd_genderMale);
            frame.add(rd_genderFemale);
            frame.add(rd_others);
            
            frame.add(lbl_ageGroup);
            frame.add(ageGroup);
            
            /*frame.add(lbl_hobbies);
            frame.add(hobbie1);
            frame.add(hobbie2);
            frame.add(hobbie3);
            
            
            frame.add(txt_pass);
            frame.add(txt_comment);
            */
            frame.add(submit);
            submit.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    Login log = new Login();
                    
                    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }
                
                
            });

            frame.add(cancel);
            cancel.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    System.exit(0);
                    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }
                
            });
            
            frame.setVisible(true);
            }

    
        public static void main(String[] args){
            Registration obj = new Registration();
            obj.RegistrationForm();
            /*LoginPage Logobj = new LoginPage();
            Logobj.Login();
*/
        }
        
    }

