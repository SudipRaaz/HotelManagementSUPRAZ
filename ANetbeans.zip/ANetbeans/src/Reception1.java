

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.ImageIcon;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

public class Reception1  {
	JTabbedPane t1=new JTabbedPane();
	
	Container c;
	//Container c1;
	JLabel l1,l2,l3, lbl_title, logo1;
        ImageIcon img;
	JTextField text1,text2,text3;
	JRadioButton r21,r22,r23;
	JCheckBox ch1,ch2,ch3;
        
        JFrame frame;
        JPanel panel, panel1,panel_table;
        ImageIcon img1;
        JLabel lbl_registrationID, lbl_room, lbl_checkIn, lbl_checkOut, lbl_roomType, lbl_roomNo;
        JTextField txt_registrationID;
        JComboBox cmb_roomInfo, cmb_roomType, cmb_roomNo; 

	public Reception1() {
                    frame = new JFrame();
        frame.setTitle("Luton Hotel - Reception");
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setBackground(Color.ORANGE); 
        
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
        JPanel p1 = new JPanel();
        JPanel p2 = new JPanel();
        JPanel p3 = new JPanel();
        tabbedPane.setBounds(50,50,500,500);
        tabbedPane.add("One",p1);
        tabbedPane.add("two",p2);
        tabbedPane.add("three",p3);
        
        
        frame.setLayout(null);
        frame.add(tabbedPane);
        frame.setVisible(true);
	}
	public static void main(String args[])	{
            Reception1 obj = new Reception1();
		              
	}
}
