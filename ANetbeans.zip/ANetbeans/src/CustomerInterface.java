/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;

import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;


/**
 *
 * @author DELL
 */
public class CustomerInterface {
    JFrame frame;
    JPanel panel_head;
    ImageIcon img;
    JLabel logo, lbl_title;
    JPanel panel_single,panel2,panel3,panel4;
    JLabel lbl1,lbl2,lbl3,lbl4,lbl5,lbl6,lbl7,lbl8;
    JButton Book_Button,Book_Button1,Book_Button2,close_button;
    ImageIcon img1,img2,img3;
    
    public void Interface(){
        frame = new JFrame();
        frame.setTitle("Customer Interface");
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);  
        
        //Fonts to select
        Font fTitle=new Font("Segoe UI Black", Font.TRUETYPE_FONT,70);
        Font font1 =new Font("Courier", Font.PLAIN,20);
        Font font2 =new Font("Courier", Font.PLAIN,25);
        
        //header part
        panel_head = new JPanel();
        img = new ImageIcon("src\\Image\\Hlogo.jpg");
        logo = new JLabel(img);
        logo.setPreferredSize(new Dimension(100,100));
        panel_head.add(logo);
        lbl_title = new JLabel("Luton Hotel");
        lbl_title.setFont(fTitle);
        panel_head.add(lbl_title);
        panel_head.setBackground(Color.orange);
        panel_head.setBounds(0, 0, 1920, 110);
        
        panel_single = new JPanel();
        panel_single.setBounds(110, 110,454,768);
        lbl1 = new JLabel();
        img1 = new ImageIcon("src\\Image\\Basic.jpg");
        lbl1 = new JLabel(img1);
        lbl1.setPreferredSize(new Dimension(400,450));
        panel_single.add(lbl1);
        lbl1.setBounds(0, 50,454, 350);
        lbl2 = new JLabel();
        lbl2.setText( "<html>     Room Type:Basic    <br>   A/C = NO  <br>   Heater = NO   </html>");
        //lbl2.setText("  A/C : YES ");
        panel_single.add(lbl2);
        lbl2.setBounds(140,300,454,400);
        lbl2.setFont(new Font("Boulder",Font.PLAIN,20));
        
        Book_Button = new JButton();
        Book_Button.setText("BOOK NOW");
        Book_Button.setBounds(140,570,150,30);
        
        frame.add(Book_Button);
        frame.add(lbl2);
       
       
       
        
        panel2 = new JPanel();
        panel2.setBounds(230,0,909,768);
        lbl3 = new JLabel();
        img2 = new ImageIcon("src\\Image\\standard.jpg");
        lbl3 = new JLabel(img2);
        lbl3.setPreferredSize(new Dimension(400,450));
        lbl3.setBounds(455, 0,909, 350);
        
        frame.add(lbl3);
        
        panel2.add(lbl3);
        lbl4 = new JLabel();
        lbl4.setText("<html>     Room Type:Standard   <br>   A/C = YES  <br>   Heater = NO    </html>");
        lbl4.setBounds(650,300,909,400);
        lbl4.setFont(new Font("Boulder",Font.PLAIN,20));
        panel2.add(lbl4);
        Book_Button1 = new JButton();
        Book_Button1.setText("BOOK NOW");
        Book_Button1.setBounds(650,570,150,30);
        
        frame.add(Book_Button1);
        frame.add(lbl4);
        
        panel3 = new JPanel();
        panel3.setBounds(700,0,1300,768);
        lbl5 = new JLabel();
        img3 = new ImageIcon("src\\Image\\delue.jpg");
        lbl5 = new JLabel(img3);
        lbl5.setPreferredSize(new Dimension(500,450));
        lbl5.setBounds(480,50,1300,350);
        frame.add(lbl5);
        
        
        lbl6 = new JLabel();
        lbl6.setText("<html>     Room Type:Deluxe   <br>   A/C = YES  <br>   Heater = YES    </html>");
        lbl6.setBounds(1050,300,909,400);
        lbl6.setFont(new Font("Boulder",Font.PLAIN,20));
        panel3.add(lbl6);
        Book_Button2 = new JButton();
        Book_Button2.setText("BOOK NOW");
        Book_Button2.setBounds(1050,570,150,30);
        
        
        
        frame.add(lbl6);
        frame.add(Book_Button2);
        
        
        close_button = new JButton();
        close_button.setText("CLOSE");
        close_button.setBounds(1180,650,150,30);
        
        frame.add(close_button);
            close_button.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                     System.exit(0);
                    
                    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }
                
                
            });
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        
        
        frame.add(panel_head);
        frame.add(panel_single);
        frame.add(panel2);
        frame.add(panel3);
        frame.setVisible(true);
    }
    public static void main(String[] args){
            CustomerInterface obj = new CustomerInterface();
            obj.Interface();
            /*LoginPage Logobj = new LoginPage();
            Logobj.Login();
*/
        }
        
    
    
}
