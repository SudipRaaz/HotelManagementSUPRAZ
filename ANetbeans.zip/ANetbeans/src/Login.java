/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JPasswordField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JSplitPane;

/**
 *
 * @author raaz4
 */
public class Login {

    JFrame frame;
    JInternalFrame iframe;
    JDesktopPane dpane;
    JPanel panel1, panel2, panel21, panel3, panel4, panel5, panel6;
    JLabel lbl_title, lbl_email, lbl_password;
    JButton btn_login, btn_register, btn_cancel;
    JSplitPane splitPane;

    public Login() {

        frame = new JFrame();
        frame.setTitle("Luton Hotel");
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setBackground(Color.ORANGE);

        //font
        Font fTitle = new Font("Courier", Font.TRUETYPE_FONT, 22);
        Font fEmail = new Font("Courier", Font.PLAIN, 17);
        Font login = new Font("Courier", Font.PLAIN, 17);
        //panel3.setFont(new Font("Times New Roman",Font.BOLD,30));

        //panel 
        panel1 = new JPanel();
        lbl_title = new JLabel("                              Enter the login details                           ");
        lbl_title.setFont(fTitle);
        panel1.add(lbl_title);
        panel1.setBackground(Color.getHSBColor(51, 10, 80));

//email and email text field 
        panel2 = new JPanel();
        lbl_email = new JLabel("  Email     : ");
        lbl_email.setFont(fEmail);
        panel2.add(lbl_email);
        panel2.add(new JTextField(20));
        panel2.setBackground(Color.getHSBColor(100, 5, 80));

        //password and password field 
        panel3 = new JPanel();
        lbl_password = new JLabel("Password : ");
        lbl_password.setFont(fEmail);
        panel3.add(lbl_password);
        panel3.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panel3.add(new JPasswordField(20));
        panel3.setBackground(Color.getHSBColor(100, 5, 80));

        panel4 = new JPanel();
        btn_login = new JButton("Login");
        btn_login.setBackground(Color.YELLOW);
        btn_login.setFont(login);

        btn_register = new JButton("Register");
        btn_register.setBackground(Color.YELLOW);
        btn_register.setFont(login);
        btn_register.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Registration reg = new Registration();
                reg.RegistrationForm();
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
        btn_cancel = new JButton("Cancel");
        btn_cancel.setBackground(Color.YELLOW);
        btn_cancel.setFont(login);
        btn_cancel.addActionListener(new ActionListenerImpl());
        panel4.add(btn_login);
        panel4.add(btn_register);
        panel4.add(btn_cancel);
        panel4.setBackground(Color.getHSBColor(51, 10, 80));

        //splitPane = new JSplitPane(SwingConstants.HORIZONTAL, panel1, panel2); 
        frame.setLayout(new FlowLayout());

        frame.add(panel1);
        frame.add(panel2);
        //frame.add(splitPane);
        frame.add(panel3);
        frame.add(panel4);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new Login();

    }
}
