/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author raaz4
 */
public class Global {
    public static String customerEmail; //after customer use email id to login
    public static int customerID;// after customer login through their credintials to customer interface is saved
    public static String customerName;// after customer login through their credintials to customer interface is saved
    //public static String bookingID;// after customer login through their credintials to customer interface is saved
    public static int staffID;// after staff login through their credintials to staff interface is saved
    public static int receptionID;// after staff login through their credintials to staff interface is saved
    public static String receptionEmail;// after receptionist login through their credintials to reception interface is saved
    public static String staffEmail;// after hotel staff login through their credintials to staff interface is saved
    
}
